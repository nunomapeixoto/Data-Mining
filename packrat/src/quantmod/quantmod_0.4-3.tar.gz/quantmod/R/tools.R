`quantmodVersion` <- function() {
  return(list(Version='0.3-7', Revision=433))
}

`quantmodNews` <- function() {

}

`quantmodChanges` <- function() {

}

`quantmodBugs` <- function() {

}

`quantmodComment` <- function() {

}

`quantmod.com` <- function() {
  browseURL('http://www.quantmod.com')
} 
